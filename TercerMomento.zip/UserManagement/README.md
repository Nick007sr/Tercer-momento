# Módulo de Gestión de Usuarios y Roles (Android)

App nativa en **Kotlin + Jetpack Compose (Material 3)**, arquitectura **MVVM** y persistencia local con **Room**.

## Cómo abrir el proyecto

1. Abre Android Studio (recomendado: Koala o superior).
2. `File > Open` y selecciona la carpeta `UserManagement`.
3. Deja que Gradle sincronice (usa Gradle 8.6, AGP 8.4.2, Kotlin 1.9.24 — se descargan solos).
4. Ejecuta en un emulador o dispositivo con **Android 7.0 (API 24)** o superior.

No se requiere ninguna configuración adicional (no usa Firebase ni claves externas): todo funciona con una base de datos Room local que se precarga con 5 usuarios de ejemplo.

## Simulación de sesión

El módulo no incluye pantalla de login. En la esquina superior derecha hay un selector
**"Sesión: <rol>"** que te permite alternar entre Administrador / Supervisor / Vendedor
para comprobar en vivo cómo cambian los permisos disponibles (con cualquier rol distinto
de Administrador, las opciones de editar/ascender/degradar/eliminar aparecen deshabilitadas).

## Reglas de negocio implementadas

- Todo usuario registrado desde el botón **"Nuevo usuario"** recibe automáticamente el rol **Vendedor**.
- Solo la sesión con rol **Administrador** puede: editar rol, ascender, degradar, cambiar estado o eliminar usuarios.
- La jerarquía de roles es `Vendedor (1) < Supervisor (2) < Administrador (3)`; ascender/degradar mueve un nivel.
- Toda acción de ascenso, descenso, cambio de estado o eliminación pide **confirmación** antes de ejecutarse.
- Los intentos sin permiso muestran un mensaje (Snackbar) explicando por qué se bloqueó la acción.

## Pantallas / componentes

- **UserListScreen**: lista de usuarios con búsqueda en tiempo real, filtros por rol y por estado (chips), FAB para registrar usuarios.
- **UserCard**: nombre, correo, badge de rol (color por rol) y badge de estado (Activo/Inactivo), menú de opciones (⋮).
- **EditRoleDialog**: asignación directa de un rol específico (solo Administrador).
- **ConfirmDialog**: confirmación reutilizable para ascender/degradar/cambiar estado/eliminar.
- **AddUserDialog**: alta de usuario nuevo (siempre queda como Vendedor).

## Estructura de carpetas

```
app/src/main/java/com/example/usermanagement/
├── data/
│   ├── model/        Role, UserEntity (Room), Converters
│   ├── local/         UserDao, AppDatabase
│   ├── repository/    UserRepository (aquí viven las reglas de permisos)
│   └── session/        SessionManager (simula el rol de sesión actual)
├── viewmodel/          UserViewModel + Factory
└── ui/
    ├── theme/          Color, Type, Theme (Material 3)
    ├── components/     RoleBadge, EstadoBadge, UserCard, SearchBar, Filtros, Diálogos
    └── screens/        UserListScreen
```

## Posibles siguientes pasos

- Reemplazar `SessionManager` por autenticación real (Firebase Auth / login propio).
- Sincronizar `UserRepository` con Firestore si se necesita almacenamiento en la nube en vez de (o además de) Room.
- Añadir paginación si la lista de usuarios crece mucho.
