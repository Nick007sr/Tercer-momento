package com.example.usermanagement.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PersonOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.usermanagement.data.model.Role
import com.example.usermanagement.data.model.UserEntity
import com.example.usermanagement.ui.components.AccionUsuario
import com.example.usermanagement.ui.components.AddUserDialog
import com.example.usermanagement.ui.components.ConfirmDialog
import com.example.usermanagement.ui.components.EditRoleDialog
import com.example.usermanagement.ui.components.FilterChipsRow
import com.example.usermanagement.ui.components.SessionRoleSelector
import com.example.usermanagement.ui.components.UserCard
import com.example.usermanagement.ui.components.UserSearchBar
import com.example.usermanagement.viewmodel.UserViewModel
import kotlinx.coroutines.launch

/** Acción pendiente de confirmación por el usuario (ascender/degradar/eliminar/cambiar estado). */
private data class AccionPendiente(val usuario: UserEntity, val accion: AccionUsuario)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserListScreen(viewModel: UserViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var mostrarDialogoAgregar by remember { mutableStateOf(false) }
    var usuarioEditandoRol by remember { mutableStateOf<UserEntity?>(null) }
    var accionPendiente by remember { mutableStateOf<AccionPendiente?>(null) }

    // Muestra el mensaje del ViewModel (éxito o error de permisos) como Snackbar.
    LaunchedEffect(uiState.mensaje) {
        uiState.mensaje?.let {
            scope.launch { snackbarHostState.showSnackbar(it) }
            viewModel.limpiarMensaje()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Usuarios y Roles") },
                actions = {
                    SessionRoleSelector(
                        rolActual = uiState.rolDeSesion,
                        onRolCambiado = viewModel::onRolDeSesionCambiado
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { mostrarDialogoAgregar = true },
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("Nuevo usuario") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            UserSearchBar(
                texto = uiState.textoBusqueda,
                onTextoCambiado = viewModel::onTextoBusquedaCambiado
            )

            Spacer(modifier = Modifier.height(10.dp))

            FilterChipsRow(
                filtroRol = uiState.filtroRol,
                filtroEstado = uiState.filtroEstado,
                onFiltroRolCambiado = viewModel::onFiltroRolCambiado,
                onFiltroEstadoCambiado = viewModel::onFiltroEstadoCambiado
            )

            Spacer(modifier = Modifier.height(10.dp))

            when {
                uiState.cargando -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) { CircularProgressIndicator() }
                }
                uiState.usuarios.isEmpty() -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            Icons.Filled.PersonOff,
                            contentDescription = null,
                            modifier = Modifier.height(48.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No se encontraron usuarios", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                else -> {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 96.dp)
                    ) {
                        items(uiState.usuarios, key = { it.id }) { usuario ->
                            UserCard(
                                usuario = usuario,
                                esAdministrador = uiState.rolDeSesion == Role.ADMINISTRADOR,
                                onAccion = { accion ->
                                    when (accion) {
                                        AccionUsuario.EditarRol -> usuarioEditandoRol = usuario
                                        else -> accionPendiente = AccionPendiente(usuario, accion)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    // Diálogo de registro de usuario nuevo (siempre queda como Vendedor)
    if (mostrarDialogoAgregar) {
        AddUserDialog(
            onConfirmar = { nombre, correo ->
                viewModel.registrarUsuario(nombre, correo)
                mostrarDialogoAgregar = false
            },
            onCancelar = { mostrarDialogoAgregar = false }
        )
    }

    // Diálogo de edición directa de rol
    usuarioEditandoRol?.let { usuario ->
        EditRoleDialog(
            usuario = usuario,
            onConfirmar = { nuevoRol ->
                viewModel.cambiarRol(usuario, nuevoRol)
                usuarioEditandoRol = null
            },
            onCancelar = { usuarioEditandoRol = null }
        )
    }

    // Diálogo de confirmación para ascender / degradar / cambiar estado / eliminar
    accionPendiente?.let { pendiente ->
        val (titulo, mensaje, textoBoton, destructivo) = obtenerTextosConfirmacion(pendiente)
        ConfirmDialog(
            titulo = titulo,
            mensaje = mensaje,
            textoConfirmar = textoBoton,
            esDestructivo = destructivo,
            onConfirmar = {
                when (pendiente.accion) {
                    AccionUsuario.Ascender -> viewModel.ascenderRol(pendiente.usuario)
                    AccionUsuario.Degradar -> viewModel.degradarRol(pendiente.usuario)
                    AccionUsuario.CambiarEstado -> viewModel.cambiarEstado(pendiente.usuario)
                    AccionUsuario.Eliminar -> viewModel.eliminarUsuario(pendiente.usuario)
                    else -> {}
                }
                accionPendiente = null
            },
            onCancelar = { accionPendiente = null }
        )
    }
}

private data class TextosConfirmacion(
    val titulo: String,
    val mensaje: String,
    val textoBoton: String,
    val destructivo: Boolean
)

private fun obtenerTextosConfirmacion(pendiente: AccionPendiente): TextosConfirmacion {
    val nombre = pendiente.usuario.nombre
    return when (pendiente.accion) {
        AccionUsuario.Ascender -> TextosConfirmacion(
            "Ascender usuario",
            "¿Deseas ascender a $nombre al siguiente rol?",
            "Ascender",
            false
        )
        AccionUsuario.Degradar -> TextosConfirmacion(
            "Degradar usuario",
            "¿Deseas degradar a $nombre al rol anterior?",
            "Degradar",
            false
        )
        AccionUsuario.CambiarEstado -> TextosConfirmacion(
            "Cambiar estado",
            "¿Deseas cambiar el estado de $nombre?",
            "Confirmar",
            false
        )
        AccionUsuario.Eliminar -> TextosConfirmacion(
            "Eliminar usuario",
            "Esta acción eliminará a $nombre de forma permanente. ¿Deseas continuar?",
            "Eliminar",
            true
        )
        AccionUsuario.EditarRol -> TextosConfirmacion("", "", "", false)
    }
}
