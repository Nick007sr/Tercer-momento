package com.example.usermanagement.ui.components

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.usermanagement.data.model.Role

/**
 * Como el módulo no incluye login, este selector simula la sesión actual para poder
 * demostrar que solo el rol Administrador puede modificar/eliminar roles y usuarios.
 */
@Composable
fun SessionRoleSelector(rolActual: Role, onRolCambiado: (Role) -> Unit) {
    var expandido by remember { mutableStateOf(false) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = { expandido = true }) {
            Icon(Icons.Filled.AccountCircle, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary)
            Text(
                "  Sesión: ${rolActual.etiqueta}",
                color = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.padding(end = 2.dp)
            )
            Icon(Icons.Filled.ArrowDropDown, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary)
        }
        DropdownMenu(expanded = expandido, onDismissRequest = { expandido = false }) {
            Role.entries.forEach { role ->
                DropdownMenuItem(
                    text = { Text("Ver como ${role.etiqueta}") },
                    onClick = { expandido = false; onRolCambiado(role) }
                )
            }
        }
    }
}
