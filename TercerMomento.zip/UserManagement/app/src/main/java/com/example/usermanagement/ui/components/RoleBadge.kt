package com.example.usermanagement.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.usermanagement.data.model.Role
import com.example.usermanagement.ui.theme.ColorAdministrador
import com.example.usermanagement.ui.theme.ColorSupervisor
import com.example.usermanagement.ui.theme.ColorVendedor

fun colorParaRol(role: Role): Color = when (role) {
    Role.ADMINISTRADOR -> ColorAdministrador
    Role.SUPERVISOR -> ColorSupervisor
    Role.VENDEDOR -> ColorVendedor
}

@Composable
fun RoleBadge(role: Role, modifier: Modifier = Modifier) {
    val color = colorParaRol(role)
    Text(
        text = role.etiqueta,
        color = color,
        style = MaterialTheme.typography.labelMedium,
        modifier = modifier
            .background(color.copy(alpha = 0.15f), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}
