package com.example.usermanagement.data.repository

import com.example.usermanagement.data.local.UserDao
import com.example.usermanagement.data.model.Role
import com.example.usermanagement.data.model.UserEntity
import com.example.usermanagement.data.session.SessionManager
import kotlinx.coroutines.flow.Flow

/** Resultado de una operación que puede fallar por falta de permisos u otra regla de negocio. */
sealed class ResultadoOperacion {
    object Exito : ResultadoOperacion()
    data class Error(val mensaje: String) : ResultadoOperacion()
}

class UserRepository(private val dao: UserDao) {

    fun observarUsuarios(): Flow<List<UserEntity>> = dao.observarUsuarios()

    /** Todo usuario que se registra recibe automáticamente el rol de Vendedor. */
    suspend fun registrarUsuario(nombre: String, correo: String): ResultadoOperacion {
        if (nombre.isBlank() || correo.isBlank()) {
            return ResultadoOperacion.Error("Nombre y correo son obligatorios")
        }
        if (dao.existeCorreo(correo) > 0) {
            return ResultadoOperacion.Error("Ya existe un usuario con ese correo")
        }
        dao.insertar(UserEntity(nombre = nombre.trim(), correo = correo.trim(), role = Role.ROL_POR_DEFECTO, activo = true))
        return ResultadoOperacion.Exito
    }

    /** Cambia el rol de un usuario a uno específico. Solo un Administrador puede hacerlo. */
    suspend fun cambiarRol(usuario: UserEntity, nuevoRol: Role): ResultadoOperacion {
        if (!SessionManager.esAdministrador()) {
            return ResultadoOperacion.Error("Solo un Administrador puede modificar roles")
        }
        dao.actualizar(usuario.copy(role = nuevoRol))
        return ResultadoOperacion.Exito
    }

    suspend fun ascenderRol(usuario: UserEntity): ResultadoOperacion {
        val siguiente = usuario.role.ascender()
            ?: return ResultadoOperacion.Error("${usuario.nombre} ya tiene el rol más alto")
        return cambiarRol(usuario, siguiente)
    }

    suspend fun degradarRol(usuario: UserEntity): ResultadoOperacion {
        val anterior = usuario.role.degradar()
            ?: return ResultadoOperacion.Error("${usuario.nombre} ya tiene el rol más bajo")
        return cambiarRol(usuario, anterior)
    }

    /** Activa/inactiva un usuario. Requiere permisos de Administrador. */
    suspend fun cambiarEstado(usuario: UserEntity): ResultadoOperacion {
        if (!SessionManager.esAdministrador()) {
            return ResultadoOperacion.Error("Solo un Administrador puede cambiar el estado")
        }
        dao.actualizar(usuario.copy(activo = !usuario.activo))
        return ResultadoOperacion.Exito
    }

    /** La eliminación de un usuario/rol solo puede hacerla un Administrador. */
    suspend fun eliminarUsuario(usuario: UserEntity): ResultadoOperacion {
        if (!SessionManager.esAdministrador()) {
            return ResultadoOperacion.Error("Solo un Administrador puede eliminar usuarios")
        }
        dao.eliminar(usuario)
        return ResultadoOperacion.Exito
    }
}
