package com.example.usermanagement

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.example.usermanagement.data.local.AppDatabase
import com.example.usermanagement.data.repository.UserRepository
import com.example.usermanagement.ui.screens.UserListScreen
import com.example.usermanagement.ui.theme.UserManagementTheme
import com.example.usermanagement.viewmodel.UserViewModel
import com.example.usermanagement.viewmodel.UserViewModelFactory

class MainActivity : ComponentActivity() {

    private val viewModel: UserViewModel by viewModels {
        val dao = AppDatabase.getInstance(applicationContext).userDao()
        UserViewModelFactory(UserRepository(dao))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            UserManagementTheme {
                UserListScreen(viewModel = viewModel)
            }
        }
    }
}
