package com.example.usermanagement.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.usermanagement.data.model.UserEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {

    /** Lista completa en tiempo real; el filtrado/búsqueda se aplica en el Repository/ViewModel. */
    @Query("SELECT * FROM usuarios ORDER BY nombre ASC")
    fun observarUsuarios(): Flow<List<UserEntity>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertar(usuario: UserEntity): Long

    @Update
    suspend fun actualizar(usuario: UserEntity)

    @Delete
    suspend fun eliminar(usuario: UserEntity)

    @Query("SELECT COUNT(*) FROM usuarios WHERE correo = :correo")
    suspend fun existeCorreo(correo: String): Int
}
