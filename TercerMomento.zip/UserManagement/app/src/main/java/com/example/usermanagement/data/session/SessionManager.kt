package com.example.usermanagement.data.session

import com.example.usermanagement.data.model.Role
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * El módulo no incluye un sistema de autenticación completo, pero todas las reglas de
 * negocio ("solo un Administrador puede...") necesitan saber qué rol tiene el usuario
 * que está usando la app en este momento. SessionManager simula esa sesión y expone
 * un selector en la UI para alternar entre roles y así poder probar los permisos.
 */
object SessionManager {
    private val _rolActual = MutableStateFlow(Role.ADMINISTRADOR)
    val rolActual: StateFlow<Role> = _rolActual

    fun cambiarRolDeSesion(nuevoRol: Role) {
        _rolActual.value = nuevoRol
    }

    fun esAdministrador(): Boolean = _rolActual.value == Role.ADMINISTRADOR
}
