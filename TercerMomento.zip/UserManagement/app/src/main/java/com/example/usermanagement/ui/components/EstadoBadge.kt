package com.example.usermanagement.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.usermanagement.ui.theme.ColorActivo
import com.example.usermanagement.ui.theme.ColorInactivo

@Composable
fun EstadoBadge(activo: Boolean, modifier: Modifier = Modifier) {
    val color = if (activo) ColorActivo else ColorInactivo
    Row(verticalAlignment = Alignment.CenterVertically, modifier = modifier) {
        Box(color)
        Text(
            text = if (activo) "Activo" else "Inactivo",
            style = MaterialTheme.typography.labelMedium,
            color = color
        )
    }
}

@Composable
private fun Box(color: androidx.compose.ui.graphics.Color) {
    androidx.compose.foundation.layout.Box(
        modifier = Modifier
            .size(8.dp)
            .background(color, CircleShape)
    )
    androidx.compose.foundation.layout.Spacer(modifier = Modifier.width(6.dp))
}
