package com.example.usermanagement.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta principal de la app
val AzulPrimario = Color(0xFF1E5AA8)
val AzulPrimarioOscuro = Color(0xFF123B70)
val AzulContenedor = Color(0xFFD6E3FF)
val FondoClaro = Color(0xFFF7F9FC)
val SuperficieClara = Color(0xFFFFFFFF)

// Colores por rol (usados en RoleBadge)
val ColorAdministrador = Color(0xFFB3261E) // rojo: máximo permiso
val ColorSupervisor = Color(0xFFB8860B)    // ámbar/dorado: intermedio
val ColorVendedor = Color(0xFF1E7A46)      // verde: rol base

// Estado activo/inactivo
val ColorActivo = Color(0xFF1E7A46)
val ColorInactivo = Color(0xFF757575)
