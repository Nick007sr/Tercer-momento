package com.example.usermanagement.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.usermanagement.data.model.Converters
import com.example.usermanagement.data.model.Role
import com.example.usermanagement.data.model.UserEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [UserEntity::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instancia = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "user_management_db"
                )
                    .addCallback(SembradorDeDatos())
                    .build()
                INSTANCE = instancia
                instancia
            }
        }
    }

    /** Precarga algunos usuarios de ejemplo para que la app no arranque vacía. */
    private class SembradorDeDatos : Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                CoroutineScope(Dispatchers.IO).launch {
                    val dao = database.userDao()
                    dao.insertar(UserEntity(nombre = "Ana Torres", correo = "ana.torres@empresa.com", role = Role.ADMINISTRADOR, activo = true))
                    dao.insertar(UserEntity(nombre = "Carlos Ruiz", correo = "carlos.ruiz@empresa.com", role = Role.SUPERVISOR, activo = true))
                    dao.insertar(UserEntity(nombre = "Diana Pérez", correo = "diana.perez@empresa.com", role = Role.VENDEDOR, activo = true))
                    dao.insertar(UserEntity(nombre = "Luis Gómez", correo = "luis.gomez@empresa.com", role = Role.VENDEDOR, activo = false))
                    dao.insertar(UserEntity(nombre = "María Salas", correo = "maria.salas@empresa.com", role = Role.SUPERVISOR, activo = true))
                }
            }
        }
    }
}
