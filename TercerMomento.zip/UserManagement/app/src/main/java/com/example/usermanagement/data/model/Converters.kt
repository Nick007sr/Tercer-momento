package com.example.usermanagement.data.model

import androidx.room.TypeConverter

/** Convierte el enum Role hacia/desde String para que Room lo pueda guardar. */
class Converters {
    @TypeConverter
    fun fromRole(role: Role): String = role.name

    @TypeConverter
    fun toRole(value: String): Role = Role.valueOf(value)
}
