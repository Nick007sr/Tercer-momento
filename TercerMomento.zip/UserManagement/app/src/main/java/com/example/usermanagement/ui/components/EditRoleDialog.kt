package com.example.usermanagement.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Row
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.usermanagement.data.model.Role
import com.example.usermanagement.data.model.UserEntity

@Composable
fun EditRoleDialog(
    usuario: UserEntity,
    onConfirmar: (Role) -> Unit,
    onCancelar: () -> Unit
) {
    var rolSeleccionado by remember { mutableStateOf(usuario.role) }

    AlertDialog(
        onDismissRequest = onCancelar,
        title = { Text("Editar rol de ${usuario.nombre}") },
        text = {
            Column {
                Role.entries.forEach { role ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .selectable(
                                selected = rolSeleccionado == role,
                                onClick = { rolSeleccionado = role }
                            ),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = rolSeleccionado == role, onClick = { rolSeleccionado = role })
                        RoleBadge(role = role, modifier = Modifier.padding(start = 4.dp))
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirmar(rolSeleccionado) }) { Text("Guardar") }
        },
        dismissButton = {
            TextButton(onClick = onCancelar) { Text("Cancelar") }
        }
    )
}
