package com.example.usermanagement.data.model

/**
 * Roles disponibles en el sistema, ordenados por jerarquía (level).
 * - VENDEDOR: rol por defecto que recibe todo usuario nuevo al registrarse.
 * - SUPERVISOR: rol intermedio, permite ascenso/descenso con sentido.
 * - ADMINISTRADOR: único rol con permisos para modificar y eliminar roles/usuarios.
 */
enum class Role(val level: Int, val etiqueta: String) {
    VENDEDOR(1, "Vendedor"),
    SUPERVISOR(2, "Supervisor"),
    ADMINISTRADOR(3, "Administrador");

    /** Rol siguiente en la jerarquía, o null si ya es el más alto. */
    fun ascender(): Role? = entries.firstOrNull { it.level == this.level + 1 }

    /** Rol anterior en la jerarquía, o null si ya es el más bajo. */
    fun degradar(): Role? = entries.firstOrNull { it.level == this.level - 1 }

    companion object {
        /** Rol asignado automáticamente a todo usuario nuevo. */
        val ROL_POR_DEFECTO = VENDEDOR
    }
}
