package com.example.usermanagement.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.usermanagement.data.model.Role
import com.example.usermanagement.data.model.UserEntity
import com.example.usermanagement.data.repository.ResultadoOperacion
import com.example.usermanagement.data.repository.UserRepository
import com.example.usermanagement.data.session.SessionManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Filtro de estado (Activo/Inactivo/Todos). */
enum class FiltroEstado { TODOS, ACTIVOS, INACTIVOS }

data class UserListUiState(
    val usuarios: List<UserEntity> = emptyList(),
    val cargando: Boolean = true,
    val textoBusqueda: String = "",
    val filtroRol: Role? = null, // null = todos los roles
    val filtroEstado: FiltroEstado = FiltroEstado.TODOS,
    val rolDeSesion: Role = Role.ADMINISTRADOR,
    val mensaje: String? = null
)

class UserViewModel(private val repository: UserRepository) : ViewModel() {

    private val _textoBusqueda = MutableStateFlow("")
    private val _filtroRol = MutableStateFlow<Role?>(null)
    private val _filtroEstado = MutableStateFlow(FiltroEstado.TODOS)
    private val _cargando = MutableStateFlow(true)
    private val _mensaje = MutableStateFlow<String?>(null)

    val uiState: StateFlow<UserListUiState> = combine(
        repository.observarUsuarios(),
        _textoBusqueda,
        _filtroRol,
        _filtroEstado,
        SessionManager.rolActual,
        _mensaje
    ) { valores ->
        @Suppress("UNCHECKED_CAST")
        val usuarios = valores[0] as List<UserEntity>
        val texto = valores[1] as String
        val filtroRol = valores[2] as Role?
        val filtroEstado = valores[3] as FiltroEstado
        val rolSesion = valores[4] as Role
        val mensaje = valores[5] as String?

        val filtrados = usuarios
            .filter { usuario ->
                texto.isBlank() ||
                    usuario.nombre.contains(texto, ignoreCase = true) ||
                    usuario.correo.contains(texto, ignoreCase = true)
            }
            .filter { filtroRol == null || it.role == filtroRol }
            .filter {
                when (filtroEstado) {
                    FiltroEstado.TODOS -> true
                    FiltroEstado.ACTIVOS -> it.activo
                    FiltroEstado.INACTIVOS -> !it.activo
                }
            }

        UserListUiState(
            usuarios = filtrados,
            cargando = false,
            textoBusqueda = texto,
            filtroRol = filtroRol,
            filtroEstado = filtroEstado,
            rolDeSesion = rolSesion,
            mensaje = mensaje
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = UserListUiState()
    )

    fun onTextoBusquedaCambiado(texto: String) {
        _textoBusqueda.value = texto
    }

    fun onFiltroRolCambiado(rol: Role?) {
        _filtroRol.value = rol
    }

    fun onFiltroEstadoCambiado(estado: FiltroEstado) {
        _filtroEstado.value = estado
    }

    fun onRolDeSesionCambiado(rol: Role) {
        SessionManager.cambiarRolDeSesion(rol)
    }

    fun registrarUsuario(nombre: String, correo: String) {
        viewModelScope.launch {
            manejarResultado(repository.registrarUsuario(nombre, correo), "Usuario registrado como Vendedor")
        }
    }

    fun cambiarRol(usuario: UserEntity, nuevoRol: Role) {
        viewModelScope.launch {
            manejarResultado(repository.cambiarRol(usuario, nuevoRol), "Rol actualizado a ${nuevoRol.etiqueta}")
        }
    }

    fun ascenderRol(usuario: UserEntity) {
        viewModelScope.launch {
            manejarResultado(repository.ascenderRol(usuario), "${usuario.nombre} fue ascendido")
        }
    }

    fun degradarRol(usuario: UserEntity) {
        viewModelScope.launch {
            manejarResultado(repository.degradarRol(usuario), "${usuario.nombre} fue degradado")
        }
    }

    fun cambiarEstado(usuario: UserEntity) {
        viewModelScope.launch {
            manejarResultado(repository.cambiarEstado(usuario), "Estado actualizado")
        }
    }

    fun eliminarUsuario(usuario: UserEntity) {
        viewModelScope.launch {
            manejarResultado(repository.eliminarUsuario(usuario), "${usuario.nombre} fue eliminado")
        }
    }

    fun limpiarMensaje() {
        _mensaje.value = null
    }

    private fun manejarResultado(resultado: ResultadoOperacion, mensajeExito: String) {
        _mensaje.value = when (resultado) {
            is ResultadoOperacion.Exito -> mensajeExito
            is ResultadoOperacion.Error -> resultado.mensaje
        }
    }
}
