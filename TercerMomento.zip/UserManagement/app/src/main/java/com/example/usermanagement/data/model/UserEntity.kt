package com.example.usermanagement.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Representa un usuario almacenado en Room.
 * Todo usuario nace con role = Role.ROL_POR_DEFECTO (Vendedor) y activo = true.
 */
@Entity(tableName = "usuarios")
data class UserEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val nombre: String,
    val correo: String,
    val role: Role = Role.ROL_POR_DEFECTO,
    val activo: Boolean = true
)
