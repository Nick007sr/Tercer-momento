package com.example.usermanagement.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.ToggleOn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.usermanagement.data.model.Role
import com.example.usermanagement.data.model.UserEntity

/** Acciones disponibles sobre un usuario desde su menú de opciones. */
sealed class AccionUsuario {
    object EditarRol : AccionUsuario()
    object Ascender : AccionUsuario()
    object Degradar : AccionUsuario()
    object CambiarEstado : AccionUsuario()
    object Eliminar : AccionUsuario()
}

@Composable
fun UserCard(
    usuario: UserEntity,
    esAdministrador: Boolean,
    onAccion: (AccionUsuario) -> Unit,
    modifier: Modifier = Modifier
) {
    var menuAbierto by remember { mutableStateOf(false) }

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Avatar con iniciales
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .background(colorParaRol(usuario.role).copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = obtenerIniciales(usuario.nombre),
                    color = colorParaRol(usuario.role),
                    style = MaterialTheme.typography.titleMedium
                )
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp)
            ) {
                Text(
                    text = usuario.nombre,
                    style = MaterialTheme.typography.bodyLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = usuario.correo,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(
                    modifier = Modifier.padding(top = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RoleBadge(role = usuario.role)
                    EstadoBadge(activo = usuario.activo)
                }
            }

            Box {
                IconButton(onClick = { menuAbierto = true }) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "Más opciones")
                }
                DropdownMenu(expanded = menuAbierto, onDismissRequest = { menuAbierto = false }) {
                    DropdownMenuItem(
                        text = { Text("Editar rol") },
                        leadingIcon = { Icon(Icons.Filled.Edit, contentDescription = null) },
                        enabled = esAdministrador,
                        onClick = { menuAbierto = false; onAccion(AccionUsuario.EditarRol) }
                    )
                    DropdownMenuItem(
                        text = { Text("Ascender de rol") },
                        leadingIcon = { Icon(Icons.Filled.ArrowUpward, contentDescription = null) },
                        enabled = esAdministrador && usuario.role != Role.ADMINISTRADOR,
                        onClick = { menuAbierto = false; onAccion(AccionUsuario.Ascender) }
                    )
                    DropdownMenuItem(
                        text = { Text("Degradar de rol") },
                        leadingIcon = { Icon(Icons.Filled.ArrowDownward, contentDescription = null) },
                        enabled = esAdministrador && usuario.role != Role.VENDEDOR,
                        onClick = { menuAbierto = false; onAccion(AccionUsuario.Degradar) }
                    )
                    DropdownMenuItem(
                        text = { Text(if (usuario.activo) "Marcar inactivo" else "Marcar activo") },
                        leadingIcon = { Icon(Icons.Filled.ToggleOn, contentDescription = null) },
                        enabled = esAdministrador,
                        onClick = { menuAbierto = false; onAccion(AccionUsuario.CambiarEstado) }
                    )
                    DropdownMenuItem(
                        text = { Text("Eliminar usuario") },
                        leadingIcon = { Icon(Icons.Filled.Delete, contentDescription = null) },
                        enabled = esAdministrador,
                        onClick = { menuAbierto = false; onAccion(AccionUsuario.Eliminar) }
                    )
                }
            }
        }
    }
}

private fun obtenerIniciales(nombre: String): String {
    val partes = nombre.trim().split(" ").filter { it.isNotBlank() }
    return when {
        partes.isEmpty() -> "?"
        partes.size == 1 -> partes[0].take(1).uppercase()
        else -> (partes[0].take(1) + partes[1].take(1)).uppercase()
    }
}
