package com.example.usermanagement.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.usermanagement.data.model.Role
import com.example.usermanagement.viewmodel.FiltroEstado

/** Fila combinada de chips: "Todos los roles" + un chip por Role, y luego un chip por FiltroEstado. */
@Composable
fun FilterChipsRow(
    filtroRol: Role?,
    filtroEstado: FiltroEstado,
    onFiltroRolCambiado: (Role?) -> Unit,
    onFiltroEstadoCambiado: (FiltroEstado) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyRow(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            FilterChip(
                selected = filtroRol == null,
                onClick = { onFiltroRolCambiado(null) },
                label = { Text("Todos los roles") }
            )
        }
        items(Role.entries.toList()) { role ->
            FilterChip(
                selected = filtroRol == role,
                onClick = { onFiltroRolCambiado(role) },
                label = { Text(role.etiqueta) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = colorParaRol(role).copy(alpha = 0.2f))
            )
        }
        item {
            FilterChip(
                selected = filtroEstado == FiltroEstado.TODOS,
                onClick = { onFiltroEstadoCambiado(FiltroEstado.TODOS) },
                label = { Text("Cualquier estado") }
            )
        }
        item {
            FilterChip(
                selected = filtroEstado == FiltroEstado.ACTIVOS,
                onClick = { onFiltroEstadoCambiado(FiltroEstado.ACTIVOS) },
                label = { Text("Activos") }
            )
        }
        item {
            FilterChip(
                selected = filtroEstado == FiltroEstado.INACTIVOS,
                onClick = { onFiltroEstadoCambiado(FiltroEstado.INACTIVOS) },
                label = { Text("Inactivos") }
            )
        }
    }
}
